import mysql.connector as sql
conn=sql.connect(host='localhost', user='root', password='root')
cursor=conn.cursor()
cursor.execute("drop database project;")
cursor.execute("create database project;")
cursor.execute("use project;")
cursor.execute("create table student_login(id varchar(6) primary key, name varchar(24), password varchar(10), email varchar(20), pno varchar(11), address varchar(40));")
cursor.execute("insert into student_login values(0001, 'Aman', 1234, 'aman@gmail.com', 9090909090, '22 Baker St');")
cursor.execute("insert into student_login values(0002, 'Yashasvi', 12345, 'yashasvi@gmail.com', 8080808080, '21 Baker St');")

cursor.execute("create table teacher_login(id varchar(6) primary key, name varchar(24), password varchar(10));")
cursor.execute("insert into teacher_login values(111,'priyanka','19');")
cursor.execute("insert into teacher_login values(112,'khushi','284');")
cursor.execute("insert into teacher_login values(113,'prachi','16');")
cursor.execute("insert into teacher_login values(114,'radha','587');")
cursor.execute("insert into teacher_login values(115,'shivanshi','869');")

cursor.execute("create table student_result(id varchar(6), CS int(3), Physics int(3), Chemistry int(3), Maths int(3), English int(3), FOREIGN KEY (id) REFERENCES student_login(id));")
cursor.execute("insert into student_result values(0001,99,90,88,91,85);")
cursor.execute("insert into student_result values(0002,95,90,87,86,92);")



conn.commit()
