import mysql.connector as sql
conn=sql.connect(host='localhost', user='root', password='root', database='project')
cursor = conn.cursor()
def student_login():
    print("Please enter your first name and password to login")
    global firstname
    global password
    firstname = input("First Name: ")
    password = input("Password: ")
    cursor.execute("SELECT * FROM student_login WHERE name = %s AND password = %s", (firstname, password))
    data = cursor.fetchall()
    if data==[]:
        print("Sorry, Student not found")
    else:
        if password==data[0][2]:
            print("\nLogin Successful!\n")
            print("Welcome", firstname.capitalize())
            while True:
                print("Please enter your choice")
                print("1. View your details")
                print("2. Update your details")
                print("3. Delete your Account")
                print("4. View Your Result")
                print("5. Exit \n")
                choice = int(input("Enter your choice: "))

                if choice==1:
                    view_details()
                elif choice==2:
                    update_details()
                elif choice==3:
                    delete_account()
                elif choice==4:
                    view_result()   
                elif choice==5:
                    print("Thank you for using our service. Have a nice day!")
                    break
                print("\nDo you wish to continue? y-yes, n-no")
                choice = input("Enter your choice: ")
                if choice in "Yy":
                    pass
                elif choice in"nN":
                    break
                else:
                    print("Sorry wrong input, Bye")
                    break
        else:
            print("Sorry Wrong Password")

def view_details():
    cursor.execute("SELECT * FROM student_login WHERE name = %s AND password = %s", (firstname, password))
    data = cursor.fetchall()
    print("Name:", data[0][1])
    print("Password:", data[0][2])
    print("Email:", data[0][3])
    print("Phone Number:", data[0][4])
    print("Address:", data[0][5])

def update_details():
    print("Please enter the details you want to update")
    print("1. Name")
    print("2. Password")
    print("3. Email")
    print("4. Phone Number")
    print("5. Address")
    choice = int(input("Enter your choice: "))

    if choice==1:
        new_name = input("Enter your new name: ")
        cursor.execute("UPDATE student_login SET name = %s WHERE name = %s AND password = %s", (new_name, firstname, password))
        conn.commit()
        print("Name updated successfully")
    elif choice==2:
        new_password = input("Enter your new password: ")
        cursor.execute("UPDATE student_login SET password = %s WHERE name = %s AND password = %s", (new_password, firstname, password))
        conn.commit()
        print("Password updated successfully")
    elif choice==3:
        new_email = input("Enter your new email: ")
        cursor.execute("UPDATE student_login SET email = %s WHERE name = %s AND password = %s", (new_email, firstname, password))
        conn.commit()
        print("Email updated successfully")
    elif choice==4:
        new_phone_number = input("Enter your new phone number: ")
        cursor.execute("UPDATE student_login SET phone_number = %s WHERE name = %s AND password = %s", (new_phone_number, firstname))
        conn.commit()
        print("Phone number updated successfully")
    elif choice==5:
        new_address = input("Enter your new address: ")
        cursor.execute("UPDATE student_login SET address = %s WHERE name = %s AND password = %s", (new_address, firstname, password))
        conn.commit()
        print("Address updated successfully")
    else:
        print("Invalid choice")

def delete_account():
    print("Are you sure you want to delete your account? This action cannot be undone.")
    choice = input("Enter Y to confirm: ")
    if choice == "Yy":
        cursor.execute("DELETE FROM student_login WHERE name = %s AND password = %s", (firstname, password))
        conn.commit()
        print("Account deleted successfully")
    else:
        print("Invalid choice")

def view_result():
    cmd='''select name, cs, physics, chemistry, maths, english from student_login, student_result
     where student_login.id=student_result.id and name like "{fname}"; '''
    cursor.execute(cmd.format(fname=firstname))
    result = cursor.fetchall()
    print('''Your Result
    CS\tPhysics\tChemistry\tMaths\tEnglish
    {cs}\t{phy}\t{chem}\t\t{maths}\t{eng}'''.format(cs=result[0][1],
    phy=result[0][2], chem=result[0][3],
    maths=result[0][4], eng=result[0][5]))