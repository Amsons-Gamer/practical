hotel=[]
def push_cust():
    n=input(input("no of customer you"))