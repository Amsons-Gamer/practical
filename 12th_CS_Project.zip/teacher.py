import mysql.connector as sql
conn=sql.connect(host='localhost', user='root',password='root', database='project')
cursor = conn.cursor()
def teacher():
    print("Please enter your Teacher UID and password to login")
    global tuid
    global password
    tuid = int(input("UID: "))
    password = input("Password: ")
    cursor.execute("SELECT * FROM teacher_login WHERE id = %s AND password = %s", (tuid, password))
    data = cursor.fetchall()
    if data==[]:
        print("Sorry, Teacher not found, or wrong password, Try Again!")
    else:
        if password==data[0][2]:
            print("\nLogin Successful!\n")
            print("Welcome", data[0][1].capitalize())
            while True:
                print("Please enter your choice")
                print("1. View your details")
                print("2. Update your details")
                print("3. View student result")
                print("4. Delete your details")
                print("5. Exit \n")
                choice = int(input("Enter your choice: "))

                if choice==1:
                    view_details()
                elif choice==2:
                    update_details()
                elif choice==3:
                    view_student_result()
                elif choice==4:
                    delete_account() 
                    break
                elif choice==5:
                    print("Thank you for using our service. Have a nice day!")
                    break
                print("\nDo you wish to continue? y-yes, n-no")
                choice = input("Enter your choice: ")
                if choice in "Yy":
                    pass
                elif choice in"nN":
                    break
                else:
                    print("Sorry wrong input, Bye")
                    break

                
        else:
            print("Sorry Wrong Password")
def view_details():
    cursor.execute("SELECT * FROM teacher_login WHERE id = %s ", (tuid,))
    data = cursor.fetchall()
    print('Teacher Id:',data[0][0])
    print("Name:", data[0][1].capitalize())
    print("Password:", data[0][2])

def update_details():
    print("Please enter the details you want to update")
    print('Teacher Id')
    print("1. Name")
    print("2. Password")
    choice = int(input("Enter your choice: "))

    if choice==1:
        new_name = input("Enter your new name: ")
        cursor.execute("UPDATE teacher_login SET name = %s WHERE id = %s", (new_name, tuid))
        conn.commit()
        print("Name updated successfully")
    elif choice==2:
        new_password = input("Enter your new password: ")
        cursor.execute("UPDATE teacher_login SET password = %s WHERE id = %s", (new_password, tuid))
        conn.commit()
        print("Password updated successfully")

    else:
        print("Invalid choice")

def delete_account():
    print("Are you sure you want to delete your account? This action cannot be undone.")
    choice = input("Enter Y to confirm: ")
    if choice in "Yy":
        cursor.execute("DELETE FROM teacher_login WHERE id = %s", (tuid, ))
        conn.commit()
        print("Account deleted successfully")
    else:
        print("Invalid choice")

def view_student_result():
    firstname = input("Enter student's Name whose result you want to see: ")
    cmd='''select name, cs, physics, chemistry, maths, english from student_login, student_result
     where student_login.id=student_result.id and name like "{fname}"; '''
    cursor.execute(cmd.format(fname=firstname))
    result = cursor.fetchall()
    print('''{fname}'s Result
    CS\tPhysics\tChemistry\tMaths\tEnglish
    {cs}\t{phy}\t{chem}\t\t{maths}\t{eng}'''.format(cs=result[0][1],
    phy=result[0][2], chem=result[0][3],
    maths=result[0][4], eng=result[0][5], fname=firstname.capitalize()))