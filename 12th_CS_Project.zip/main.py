import mysql.connector as sql
import teacher
import student
conn=sql.connect(host='localhost', user='root', password='root', database='project')
def main():   
    print("\t\t\t\t\t\tWelcome to School Management System 😃")
    print("Are you a Teacher or a Student ?")
    print("1. Teacher")
    print("2. Student")

main()
choice=int(input("Enter your choice: "))
if choice==1:
    teacher.teacher()
elif choice==2:
    student.student_login()
else:
    print("Please enter a valid Choice")
    main()
