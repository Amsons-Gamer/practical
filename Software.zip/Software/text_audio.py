from gtts import gTTS

# valid = gTTS("Please enter a valid choice!")
# valid.save('./Software/svalid.mp3')

# intro = gTTS('''  Welcome to the adventure game!
# Which Adventure would you like to choose?
# 1. Fiction 1 or 2. Fiction 2''')
# intro.save('./Software/sintro.mp3')

# sfiction1 = gTTS('''  You are now in the magical kingdom. You see a towering castle, and a bustling market. Where would you like to go?
# 1.“The towering castle”
# 2.“The bustling market”''')
# sfiction1.save('./Software/sfiction1.mp3')

# stowering_castle = gTTS('''  You are now in the towering castle. You see a grand throne room and a mysterious library. Where would you like to go?
# 1. The grand throne room
# 2. The mysterious library''')
# stowering_castle.save('./Software/stowering_castle.mp3')

# sthrone = gTTS('''  You are now in the grand throne room. You see a majestic throne and a royal crown. What would you like to do?
# 1. Sit on the throne
# 2.Inspect the royal crown ''')
# sthrone.save('./Software/sthrone.mp3')

# ssit = gTTS('''  As you sit on the throne, you feel a sense of power. What would you like to do next?
# 1. Make a royal decree
# 2. Call for a feast
# 3. Explore the castle further''')
# ssit.save('./Software/ssit.mp3')

# sdecree = gTTS('''After making a royal decree, you notice a change in the kingdom. 
#     The people start following your decree, and it brings prosperity and happiness to everyone. 
#     The kingdom flourishes under your wise rule, and peace prevails. The people are content, and they respect and admire you. 
#     You continue to rule the kingdom with wisdom and kindness, and everyone lives happily ever after.''')
# sdecree.save('./Software/sdecree.mp3')

# sfeast = gTTS('''After ordering a grand feast, the kingdom comes alive with joy and celebration. 
# The people are touched by your generosity and kindness. This act of goodwill earns you the respect and loyalty of your subjects. 
# They start following your rule with renewed faith and enthusiasm. The kingdom thrives under your benevolent rule, and peace and prosperity reign. 
# Everyone in the kingdom lives happily ever after. ''')
# sfeast.save('./Software/sfeast.mp3')

# sexplore = gTTS('''As you explore the castle further, you encounter a guard. 
#     Seeing your confidence and the way you carry yourself, the guard mistakes you for the ruler. 
#     Word quickly spreads throughout the castle and soon, the entire kingdom. 
#     The people, inspired by your wisdom and leadership, start following you. Under your rule, the kingdom experiences an era of peace and prosperity.
#     Everyone in the kingdom lives happily ever after.
# ''')
# sexplore.save('./Software/sexplore.mp3')

# ssearch = gTTS('''As you search the castle further, you encounter a guard. 
#     Seeing your confidence and the way you carry yourself, the guard mistakes you for the ruler. 
#     Word quickly spreads throughout the castle and soon, the entire kingdom. 
#     The people, inspired by your wisdom and leadership, start following you. Under your rule, the kingdom experiences an era of peace and prosperity.
#     Everyone in the kingdom lives happily ever after.
# ''')
# ssearch.save('./Software/ssearch.mp3')

# sdecipher = gTTS('''Unable to decipher the inscription, you decide to visit a scholar in the kingdom. 
#     After showing him the inscription, he studies it for a moment before his eyes widen in surprise. 
#     (male audio) he says, (male audio) The news spreads throughout the kingdom, and the people accept you as their new ruler.
#     Under your wise and just rule, the kingdom thrives and everyone lives happily ever after.
# ''')
# sdecipher.save('./Software/sdecipher.mp3')
  
# sscholor = gTTS('''After showing the inscription to a scholar, he reads it and his eyes widen in surprise. 
#     (male audio) he says, (male audio) The news spreads throughout the kingdom, and the people accept you as their new ruler.
#     Under your wise and just rule, the kingdom thrives and everyone lives happily ever after.
# ''')
# sscholor.save('./Software/sscholor.mp3')

# sinspect = gTTS('''Upon inspecting the royal crown, you discover a hidden inscription. What do you do?
#     1. Try to decipher the inscription
#     2. Show the inscription to a scholar in the kingdom 
#     3. Search the castle for clues about the inscription ''')
# sinspect.save('./Software/sinspect.mp3')
  
# slibrary = gTTS('''You are now in the mysterious library. You see shelves filled with ancient books and a hidden scroll. What would you like to do?
#     1. Read the ancient books
#     2. Inspect the hidden scroll ''')
# slibrary.save('./Software/slibrary.mp3')
  
# sbook = gTTS('''As you read the ancient books, you learn about the castle\'s history and legends. What would you like to do next?")
#     1. Investigate the legends
#     2. Share your knowledge with the kingdom ''')
# sbook.save('./Software/sbook.mp3')
  
# sinvestigate = gTTS('''As you investigate the castle further, you encounter a guard. 
#     Seeing your confidence and the way you carry yourself, the guard mistakes you for the ruler. 
#     Word quickly spreads throughout the castle and soon, the entire kingdom. 
#     The people, inspired by your wisdom and leadership, start following you. Under your rule, the kingdom experiences an era of peace and prosperity. 
#     Everyone in the kingdom lives happily ever after. ''')
# sinvestigate.save('./Software/sinvestigate.mp3')
  
# sshare = gTTS('''After sharing your knowledge with an old man in the kingdom, he reveals himself to be the previous king. 
#     Touched by your wisdom and respect for the kingdom\'s history, he declares you the new king. 
#     The news spreads throughout the kingdom, and the people accept you as their new ruler. 
#     Under your wise and just rule, the kingdom thrives and everyone lives happily ever after.''')
# sshare.save('./Software/sshare.mp3')
  
# sscroll = gTTS('''While roaming around the library you found a Hidden Scroll. What do you do?
#     1. Try to decipher the inscription
#     2. Show the inscription to a scholar in the kingdom ''')
# sscroll.save('./Software/sscroll.mp3')

# sbustling_market = gTTS('''As you wander through the bustling market, you are captivated by the sights and sounds. What would you like to do next?")
#     1. Visit the local blacksmith
#     2. Buy supplies for your journey''')
# sbustling_market.save('./Software/sbustling_market.mp3')

# sblacksmith = gTTS('''After speaking with the blacksmith, you learn about various weapons and armors. What would you like to do next? ")
#     1. Purchase a new weapon
#     2. Ask the blacksmith for advice on your journey  ''')
# sblacksmith.save('./Software/sblacksmith.mp3')

# spurchase = gTTS('''Just as you complete your purchase, a sudden commotion erupts in the market. What would you like to do next?")
#     1. Rush to help the people in the market
#     2. Hide and observe the situation
#     3. Use your newly purchased item to defend the market ''')
# spurchase.save('./Software/spurchase.mp3')

# srush = gTTS('''As you rush towards the commotion, a surge of confidence fills you. 
#     With courage and determination, you manage to save the people from the chaos. 
#     Overwhelmed with gratitude, they hail you as their hero and accept you as their rightful ruler.''')
# srush.save('./Software/srush.mp3')

# shide = gTTS('''Choosing to hide and observe, you are spotted by the attackers. 
#     In self-defense, you are forced to confront them. Displaying bravery and skill, you defeat the attackers, ensuring the safety of the market. ''')
# shide.save('./Software/shide.mp3')

# sdefend = gTTS('''Deciding to use your newly purchased item, you step forward to defend the market. 
#     Your successful defense against the attackers leads the people to believe that you are a ruler in disguise, who has come to protect them.  ''')
# sdefend.save('./Software/sdefend.mp3')

# sadvice = gTTS('''Just as the blacksmith is about to share his advice, a sudden commotion erupts in the market. An attack! What would you like to do next?
#     1. Rush to help the people in the market
#     2. Hide and observe the situation
#     3. Grab a new sword to defend the market ''')
# sadvice.save('./Software/sadvice.mp3')

# sdefend2 = gTTS('''Deciding to use your new Sword, you step forward to defend the market. 
#     Your successful defense against the attackers leads the people to believe that you are a ruler in disguise, who has come to protect them.''')
# sdefend2.save('./Software/sdefend2.mp3')

# sdefend3 = gTTS('''Empowered by the strength potion, you feel an incredible surge of energy coursing through your veins. 
#     With newfound strength and determination, you bravely confront the attackers. 
#     The battle is fierce, but you stand your ground, your every move a testament to your strength. 
#     Finally, the last of the attackers falls, and the market is safe once more. You, the unexpected hero, have saved the day.
#     Your successful defense against the attackers leads the people to believe that you are a ruler in disguise, who has come to protect them..''')
# sdefend3.save('./Software/sdefend3.mp3')

# ssupplies = gTTS(''' As you\'re buying drinks and other supplies, your eyes catch a potion labeled \'Strength\'. Intrigued, you decide to purchase it. After a few sips, you feel a surge of bravery coursing through you. Just as you\'re enjoying this newfound courage, a sudden commotion disrupts the market. An attack! What would you like to do next?
#     1. Rush to help the people in the market
#     2. Hide and observe the situation
#     3. Use your newly purchased item to defend the market''')
# ssupplies.save('./Software/ssupplies.mp3')

# scont = gTTS(''' Do you want to play this game again ? 
# 1. Yes
# 2. No ''')
# scont.save('./Software/Sounds/scont.mp3')

sty = gTTS('''Thank You For playing the Game!''')
sty.save('./Software/Sounds/sty.mp3')