import pygame
pygame.init()

#for sounds/audios
svalid = pygame.mixer.Sound('.\Sounds\svalid.mp3')
start = pygame.mixer.Sound('.\Sounds\game_start.mp3')
sfiction1 = pygame.mixer.Sound('.\Sounds\sfiction1.mp3')
castle =pygame.mixer.Sound('.\Sounds\castle.mp3')
tcastle = pygame.mixer.Sound('.\Sounds\stowering_castle.mp3')
sthrone = pygame.mixer.Sound('.\Sounds\sthrone.mp3')
ssit = pygame.mixer.Sound('.\Sounds\ssit.mp3')
sdecree = pygame.mixer.Sound('.\Sounds\sdecree.mp3')
sfeast = pygame.mixer.Sound('.\Sounds\sfeast.mp3')
sexplore = pygame.mixer.Sound('.\Sounds\sexplore.mp3')
sinspect = pygame.mixer.Sound('.\Sounds\sinspect.mp3')
sdecipher = pygame.mixer.Sound('.\Sounds\sdecipher.mp3')
sscholar = pygame.mixer.Sound('.\Sounds\sscholor.mp3')
ssearch = pygame.mixer.Sound('.\Sounds\ssearch.mp3')
slibrary = pygame.mixer.Sound('.\Sounds\slibrary.mp3')
sbook = pygame.mixer.Sound('.\Sounds\sbook.mp3')
sinvestigate = pygame.mixer.Sound('.\Sounds\sinvestigate.mp3')
sshare = pygame.mixer.Sound('.\Sounds\sshare.mp3')
sscroll = pygame.mixer.Sound('.\Sounds\sscroll.mp3')
scont = pygame.mixer.Sound('.\Sounds\scont.mp3')
sty = pygame.mixer.Sound('.\Sounds\sty.mp3')

cont = False

def thankyou():
    print("Thank You for playing The Game")
    sty.play()

def fiction(): 
    towering_castle() #Main Starting

def replay():
    print("Do you want to play this game again ? ")
    print("1. Yes")
    print("2. No")
    scont.play()
    choice = input("> ")
    if choice == "1":
        cont = True
    elif choice == "2":
        cont = False
    else:
        print("Please enter a valid choice.")
        svalid.play()
        replay()

def towering_castle(): 
    castle.play()
    pygame.time.delay(int(castle.get_length() * 950))
    print("You are now in the towering castle. You see a grand throne room and a mysterious library. Where would you like to go?")
    print("1. The grand throne room")
    print("2. The mysterious library")
    tcastle.play()
    choice = input("> ")
    if choice == "1":
        throne()
    elif choice == "2":
        library()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        towering_castle()

def throne(): 
    print("You are now in the grand throne room. You see a majestic throne and a royal crown. What would you like to do? ")
    print("1. Sit on the throne")
    print("2. Inspect the royal crown ")
    sthrone.play()
    choice = input("> ")
    if choice == "1":
        sit()
    elif choice == "2":
        inspect()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        throne()

def sit(): 
    print("As you sit on the throne, you feel a sense of power. What would you like to do next? ")
    print("1. Make a royal decree")
    print("2. Call for a feast")
    print("3. Explore the castle further")
    ssit.play()
    choice = input("> ")
    if choice == "1":
        decree()
    elif choice == "2":
        feast()
    elif choice=="3":
        explore()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        sit()

def decree(): 
    print('''After making a royal decree, you notice a change in the kingdom. 
    The people start following your decree, and it brings prosperity and happiness to everyone. 
    The kingdom flourishes under your wise rule, and peace prevails. The people are content, and they respect and admire you. 
    You continue to rule the kingdom with wisdom and kindness, and everyone lives happily ever after.''')
    sdecree.play()
    pygame.time.delay(int(sdecree.get_length()*1000))
    replay()

def feast(): 
    print('''After making a royal decree, you notice a change in the kingdom. 
    The people start following your decree, and it brings prosperity and happiness to everyone. 
    The kingdom flourishes under your wise rule, and peace prevails. The people are content, and they respect and admire you. 
    You continue to rule the kingdom with wisdom and kindness, and everyone lives happily ever after.''')
    sfeast.play()
    pygame.time.delay(int(sfeast.get_length()*1000))
    replay()

def explore(): 
    print('''As you explore the castle further, you encounter a guard. 
    Seeing your confidence and the way you carry yourself, the guard mistakes you for the ruler. 
    Word quickly spreads throughout the castle and soon, the entire kingdom. 
    The people, inspired by your wisdom and leadership, start following you. Under your rule, the kingdom experiences an era of peace and prosperity.
    Everyone in the kingdom lives happily ever after. ''')
    sexplore.play()
    pygame.time.delay(int(sexplore.get_length()*1000))
    replay()

def inspect(): 
    print('''Upon inspecting the royal crown, you discover a hidden inscription. What do you do?''')
    print("1. Try to decipher the inscription")
    print("2. Show the inscription to a scholar in the kingdom ")
    print("3. Search the castle for clues about the inscription")
    sinspect.play()
    choice = input("> ")
    if choice == "1":
        decipher()
    elif choice == "2":
        scholar()
    elif choice == "3":
        search()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        throne()

def decipher(): 
    print('''Unable to decipher the inscription, you decide to visit a scholar in the kingdom. 
    After showing him the inscription, he studies it for a moment before his eyes widen in surprise. 
    \'This is an ancient prophecy,\' he says, \'It states that whoever finds this hidden inscription will become the ruler of this kingdom.
    You have fulfilled the prophecy. You are now our ruler.\' The news spreads throughout the kingdom, and the people accept you as their new ruler.
    Under your wise and just rule, the kingdom thrives and everyone lives happily ever after.''')
    sdecipher.play()
    pygame.time.delay(int(sdecipher.get_length()*1000))
    replay()
    

def scholar(): 
    print('''After showing the inscription to a scholar, he reads it and his eyes widen in surprise. 
    \'This is an ancient prophecy,\' he says, \'It states that whoever finds this hidden inscription will become the ruler of this kingdom. 
    You have fulfilled the prophecy. You are now our ruler.\' The news spreads throughout the kingdom, and the people accept you as their new ruler.
    Under your wise and just rule, the kingdom thrives and everyone lives happily ever after.''')
    sscholar.play()
    pygame.time.delay(int(sscholar.get_length()*1000))
    replay()

def search(): 
    print('''As you search the castle further, you encounter a guard. 
    Seeing your confidence and the way you carry yourself, the guard mistakes you for the ruler. 
    Word quickly spreads throughout the castle and soon, the entire kingdom. 
    The people, inspired by your wisdom and leadership, start following you. Under your rule, the kingdom experiences an era of peace and prosperity.
    Everyone in the kingdom lives happily ever after. ''')
    ssearch.play()
    pygame.time.delay(int(ssearch.get_length()*1000))
    replay()

def library(): 
    print("You are now in the mysterious library. You see shelves filled with ancient books and a hidden scroll. What would you like to do?")
    print("1. Read the ancient books")
    print("2. Inspect the hidden scroll")
    slibrary.play()
    choice = input("> ")
    if choice == "1":
        book()
    elif choice == "2":
        scroll()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        library()

def book(): 
    print("As you read the ancient books, you learn about the castle\'s history and legends. What would you like to do next?")
    print("1. Investigate the legends")
    print("2. Share your knowledge with the kingdom")
    sbook.play()
    choice = input("> ")
    if choice == "1":
        investigate()
    elif choice == "2":
        share()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        book()

def investigate(): 
    print('''As you investigate the castle further, you encounter a guard. 
    Seeing your confidence and the way you carry yourself, the guard mistakes you for the ruler. 
    Word quickly spreads throughout the castle and soon, the entire kingdom. 
    The people, inspired by your wisdom and leadership, start following you. Under your rule, the kingdom experiences an era of peace and prosperity. 
    Everyone in the kingdom lives happily ever after. ''')
    sinvestigate.play()
    pygame.time.delay(int(sinvestigate.get_length()*1000))
    replay()

def share(): 
    print('''After sharing your knowledge with an old man in the kingdom, he reveals himself to be the previous king. 
    Touched by your wisdom and respect for the kingdom\'s history, he declares you the new king. 
    The news spreads throughout the kingdom, and the people accept you as their new ruler. 
    Under your wise and just rule, the kingdom thrives and everyone lives happily ever after.''')
    sshare.play()
    pygame.time.delay(int(sshare.get_length()*1000))
    replay()

def scroll(): 
    print('''While roaming around the library you found a Hidden Scroll. What do you do?''')
    print("1. Try to decipher the inscription")
    print("2. Show the inscription to a scholar in the kingdom ")
    sscroll.play()
    choice = input("> ")
    if choice == "1":
        decipher()
    elif choice == "2":
        scholar()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        scroll()





