import pygame
pygame.init()

castle =pygame.mixer.Sound('.\Sounds\castle.mp3')
sbustling_market = pygame.mixer.Sound('.\Sounds\sbustling_market.mp3')
sblacksmith = pygame.mixer.Sound('.\Sounds\sblacksmith.mp3')
spurchase = pygame.mixer.Sound('.\Sounds\spurchase.mp3')
srush = pygame.mixer.Sound('.\Sounds\srush.mp3')
shide = pygame.mixer.Sound('.\Sounds\shide.mp3')
ssupplies = pygame.mixer.Sound('.\Sounds\ssupplies.mp3')
sdefend = pygame.mixer.Sound('.\Sounds\sdefend.mp3')
sadvice = pygame.mixer.Sound('.\Sounds\sadvice.mp3')
sdefend2 = pygame.mixer.Sound('.\Sounds\sdefend2.mp3')
sdefend3 = pygame.mixer.Sound('.\Sounds\sdefend3.mp3')
scont = pygame.mixer.Sound('.\Sounds\scont.mp3')

def fiction():
    bustling_market()

cont = False
def replay():
    print("Do you want to play this game again ? ")
    print("1. Yes")
    print("2. No")
    scont.play()
    choice = input("> ")
    if choice == "1":
        cont = True
    elif choice == "2":
        cont = False
    else:
        print("Please enter a valid choice.")
        svalid.play()
        replay()

def bustling_market(): 
    castle.play()
    pygame.time.delay(int(castle.get_length() * 950))
    print("As you wander through the bustling market, you are captivated by the sights and sounds. What would you like to do next?")
    print("1. Visit the local blacksmith")
    print("2. Buy supplies for your journey")
    sbustling_market.play()
    choice = input("> ")
    if choice == "1":
        blacksmith() #Done
    elif choice == "2":
        supplies() #Done
    else:
        print("Please enter a valid choice.")
        svalid.play()
        bustling_market()

def blacksmith(): #Done
    print("After speaking with the blacksmith, you learn about various weapons and armors. What would you like to do next? ")
    print("1. Purchase a new weapon")
    print("2. Ask the blacksmith for advice on your journey ")
    sblacksmith.play()
    choice = input("> ")
    if choice == "1":
        purchase() #Done
    elif choice == "2":
        advice()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        blacksmith()

def purchase():  #Done
    print("Just as you complete your purchase, a sudden commotion erupts in the market. What would you like to do next?")
    print("1. Rush to help the people in the market")
    print("2. Hide and observe the situation")
    print("3. Use your newly purchased item to defend the market")
    spurchase.play()
    choice = input("> ")
    if choice == "1":
        rush()
    elif choice == "2":
        hide()
    elif choice=="3":
        defend()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        purchase()
def rush(): 
    print(''' As you rush towards the commotion, a surge of confidence fills you. 
    With courage and determination, you manage to save the people from the chaos. 
    Overwhelmed with gratitude, they hail you as their hero and accept you as their rightful ruler.''')
    srush.play()
    pygame.time.delay(int(srush.get_length()*1000))
    replay()
def hide(): 
    print('''Choosing to hide and observe, you are spotted by the attackers. 
    In self-defense, you are forced to confront them. Displaying bravery and skill, you defeat the attackers, ensuring the safety of the market.''')
    shide.play()
    pygame.time.delay(int(shide.get_length()*1000))
    replay()
def defend(): 
    print('''Deciding to use your newly purchased item, you step forward to defend the market. 
    Your successful defense against the attackers leads the people to believe that you are a ruler in disguise, who has come to protect them. ''')
    sdefend.play()
    pygame.time.delay(int(sdefend.get_length()*1000))
    replay()

def advice():  #Done
    print('''Just as the blacksmith is about to share his advice, a sudden commotion erupts in the market. An attack! What would you like to do next?''')
    print("1. Rush to help the people in the market")
    print("2. Hide and observe the situation")
    print("3. Grab a new sword to defend the market")
    sadvice.play()
    choice = input("> ")
    if choice == "1":
        rush()
    elif choice == "2":
        hide()
    elif choice == "3":
        defend2()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        advice()
def defend2(): 
    print('''Deciding to use your new Sword, you step forward to defend the market. 
    Your successful defense against the attackers leads the people to believe that you are a ruler in disguise, who has come to protect them. ''')
    sdefend2.play()
    pygame.time.delay(int(sdefend2.get_length()*1000))
    replay()

def supplies():  #Done
    print(" As you\'re buying drinks and other supplies, your eyes catch a potion labeled \'Strength\'. Intrigued, you decide to purchase it. After a few sips, you feel a surge of bravery coursing through you. Just as you\'re enjoying this newfound courage, a sudden commotion disrupts the market. An attack! What would you like to do next?")
    print("1. Rush to help the people in the market")
    print("2. Hide and observe the situation")
    print("3. Use your newly purchased item to defend the market")
    ssupplies.play()
    choice = input("> ")
    if choice == "1":
        rush()
    elif choice == "2":
        hide()
    elif choice == "3":
        defend3()
    else:
        print("Please enter a valid choice.")
        svalid.play()
        supplies()
def defend3():
    print('''Empowered by the strength potion, you feel an incredible surge of energy coursing through your veins. 
    With newfound strength and determination, you bravely confront the attackers. 
    The battle is fierce, but you stand your ground, your every move a testament to your strength. 
    Finally, the last of the attackers falls, and the market is safe once more. You, the unexpected hero, have saved the day.
    Your successful defense against the attackers leads the people to believe that you are a ruler in disguise, who has come to protect them.''')
    sdefend3.play()
    pygame.time.delay(int(sdefend3.get_length()*1000))
    replay()












