import fiction
import scifi
import pygame
pygame.init()
intro = pygame.mixer.Sound('.\Sounds\sintro.mp3')
def start_game():
    print('----------------------------------------')
    print("Welcome to the adventure game!")
    print("Which Adventure would you like to choose")
    print("1. Fiction 1")
    print("2. Fiction 2")
    intro.play()
    choice = input("> ")
    if choice == "1":
        fiction.fiction()
    elif choice == "2":
        scifi.fiction()
    else:
        print("Please enter a valid choice.")
        start_game()
start_game()
if fiction.cont == True or scifi.cont == True:
    start_game()

else:
    fiction.thankyou()

    
